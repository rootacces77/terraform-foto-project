import os
import posixpath
import uuid
from urllib.parse import unquote_plus

import boto3
from botocore.exceptions import ClientError
from PIL import Image, ImageOps

s3 = boto3.client("s3")

# --- Config ---
SOURCE_PREFIX = os.getenv("SOURCE_PREFIX", "gallery/")
THUMB_DIRNAME = os.getenv("THUMB_DIRNAME", ".thumb")
THUMB_PREFIX = os.getenv("THUMB_PREFIX", "thumb-of-")

THUMB_MAX_SIZE = int(os.getenv("THUMB_MAX_SIZE", "480"))     # px (max of width/height)
JPEG_QUALITY = int(os.getenv("JPEG_QUALITY", "75"))
CACHE_CONTROL = os.getenv("CACHE_CONTROL", "public, max-age=31536000, immutable")

# Optional optimizations
MIN_ORIGINAL_BYTES = int(os.getenv("MIN_ORIGINAL_BYTES", "0"))  # e.g. 250000 to skip tiny files
SKIP_IF_ALREADY_SMALL = os.getenv("SKIP_IF_ALREADY_SMALL", "true").lower() == "true"
CREATE_THUMB_FOLDER_MARKER = os.getenv("CREATE_THUMB_FOLDER_MARKER", "true").lower() == "true"

IMAGE_EXTS = {".jpg", ".jpeg", ".png", ".webp", ".tif", ".tiff", ".bmp"}


def is_thumb_key(key: str) -> bool:
    return f"/{THUMB_DIRNAME}/" in f"/{key}"


def is_image_key(key: str) -> bool:
    return (posixpath.splitext(key)[1] or "").lower() in IMAGE_EXTS


def thumb_key_for(original_key: str) -> str:
    d = posixpath.dirname(original_key)  # gallery/album
    base = posixpath.basename(original_key)
    return posixpath.join(d, THUMB_DIRNAME, f"{THUMB_PREFIX}{base}")


def ensure_thumb_folder_marker(bucket: str, album_dir: str):
    """
    Creates a zero-byte object '.../.thumb/' so file browsers show the folder.
    Safe because our event handler skips /.thumb/ keys.
    """
    marker_key = posixpath.join(album_dir, THUMB_DIRNAME) + "/"
    try:
        s3.head_object(Bucket=bucket, Key=marker_key)
        return
    except ClientError as e:
        code = e.response.get("Error", {}).get("Code", "")
        if code not in ("404", "NoSuchKey", "NotFound"):
            raise

    s3.put_object(
        Bucket=bucket,
        Key=marker_key,
        Body=b"",
        ContentType="application/x-directory",
        CacheControl="no-store",
    )


def choose_output(img: Image.Image):
    # If transparency -> PNG, else JPEG (smaller/faster for photos)
    mode = (img.mode or "").upper()
    has_alpha = ("A" in mode) or ("transparency" in img.info)
    if has_alpha:
        return ("PNG", "image/png", ".png")
    return ("JPEG", "image/jpeg", ".jpg")


def lambda_handler(event, context):
    records = event.get("Records", [])
    out = {"processed": 0, "skipped": 0, "errors": 0, "items": []}

    for r in records:
        try:
            bucket = r["s3"]["bucket"]["name"]
            key = unquote_plus(r["s3"]["object"]["key"])

            # Ignore non-targets
            if not key.startswith(SOURCE_PREFIX) or key.endswith("/") or is_thumb_key(key) or not is_image_key(key):
                out["skipped"] += 1
                out["items"].append({"key": key, "status": "skipped"})
                continue

            obj_size = int(r["s3"]["object"].get("size", 0) or 0)
            if MIN_ORIGINAL_BYTES and obj_size and obj_size < MIN_ORIGINAL_BYTES:
                out["skipped"] += 1
                out["items"].append({"key": key, "status": "skipped", "reason": "min_bytes"})
                continue

            album_dir = posixpath.dirname(key)  # gallery/<album>
            if CREATE_THUMB_FOLDER_MARKER:
                ensure_thumb_folder_marker(bucket, album_dir)

            src_tmp = f"/tmp/src-{uuid.uuid4().hex}"
            out_tmp = f"/tmp/out-{uuid.uuid4().hex}"

            s3.download_file(bucket, key, src_tmp)

            with Image.open(src_tmp) as im:
                im = ImageOps.exif_transpose(im)  # fixes iPhone rotation
                w, h = im.size

                if SKIP_IF_ALREADY_SMALL and max(w, h) <= THUMB_MAX_SIZE:
                    # Still create a thumb? If your frontend expects thumbs always,
                    # set SKIP_IF_ALREADY_SMALL=false.
                    out["skipped"] += 1
                    out["items"].append({"key": key, "status": "skipped", "reason": "already_small"})
                    continue

                im.thumbnail((THUMB_MAX_SIZE, THUMB_MAX_SIZE), Image.Resampling.LANCZOS)

                fmt, content_type, out_ext = choose_output(im)

                thumb_key = thumb_key_for(key)
                # If output format changes extension (e.g. PNG->JPG), update thumb key extension
                root, _ = posixpath.splitext(thumb_key)
                thumb_key = root + out_ext

                save_kwargs = {}
                if fmt == "JPEG":
                    if im.mode not in ("RGB", "L"):
                        im = im.convert("RGB")
                    save_kwargs.update({"quality": JPEG_QUALITY, "optimize": True, "progressive": True})
                else:
                    save_kwargs.update({"optimize": True})

                im.save(out_tmp, format=fmt, **save_kwargs)

            s3.upload_file(
                out_tmp,
                bucket,
                thumb_key,
                ExtraArgs={
                    "ContentType": content_type,
                    "CacheControl": CACHE_CONTROL,
                },
            )

            out["processed"] += 1
            out["items"].append({"key": key, "thumb": thumb_key, "status": "ok"})

        except Exception as e:
            out["errors"] += 1
            out["items"].append({"status": "error", "error": str(e)})

    return out